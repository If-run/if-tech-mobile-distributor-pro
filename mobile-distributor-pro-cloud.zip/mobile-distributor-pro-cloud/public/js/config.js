/* =========================================================================
   MOBILE DISTRIBUTOR PRO — CONFIGURATION
   This is the ONLY file you need to edit before deploying.
   1. Create a Firebase project (see SETUP-GUIDE.md, step 1).
   2. Paste your web app config below.
   ========================================================================= */

export const FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};

// Product name shown on login screen, invoices and SMS.
export const APP_NAME = 'Mobile Distributor Pro';

// true  = anyone can register a new shop from the login screen (gets a free trial)
// false = only you create shops (use admin.html), sign-up button is hidden
export const ALLOW_SIGNUP = true;

// Free trial length for new shops (days). Firestore rules cap this at 15.
export const TRIAL_DAYS = 14;

// Your contact number, shown to shops when their subscription expires.
export const SUPPORT_PHONE = '';
